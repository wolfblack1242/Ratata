<?php
$site = "https://dev-padsag.pantheonsite.io/"; //آدرس ریموتت بدون پوشه (پورت) مثال : https://madsal.com/
//دوست عزیز این لینک باید بصورت انکریپت توی رت قرار بگیره پس اول پنل رو ران کن و دستور /Madsal رو واسه ربات بفرست تا لینک انکریپت رو بهت بده
//➖➖➖➖➖➖➖➖➖➖➖
$sudo_port = "zx"; //این پورتته دیفالتش همینه و اسم پوشت هم باید همین باشه ولی اگه خواستی عوض کنی توی رت assets/sudoport.txt رو هم همون بزار.
//➖➖➖➖➖➖➖➖➖➖➖
$bot_token ="7348320016:AAF7jVtH0Kn-8Wzk4ZF52UWtt0btrFlOG78";
$dev_id = "@mr_pishv";
$dev_name = "Pishva";
$sudo_user = ["6325337148"];
$id_sender ="6325337148";
//➖➖➖➖➖➖➖➖➖➖➖
//این دوتا متغییر پایین رو دست نزن اگه از رت من استفاده میکنی
$file="unix-7850a-firebase-adminsdk-fbsvc-34959d578e.json";
$project_id="unix-7850a";
?>